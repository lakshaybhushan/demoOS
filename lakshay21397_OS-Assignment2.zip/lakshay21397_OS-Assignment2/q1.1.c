#include <stdio.h>
#include <math.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/resource.h>
#include <time.h>
#define BILLION 1000000000L
pthread_t t1, t2, t3;

void *countA()
{
    struct sched_param counta_param;
    counta_param.sched_priority = 0;
    pthread_setschedparam(t1, SCHED_OTHER, &counta_param);
    nice(19);
    struct timespec runtime1, runtime2;
    double time_taken;
    clock_gettime(CLOCK_REALTIME, &runtime1);
    long long count = 0;
    for (long long int i = 1; i < pow(2, 32); i++)
    {
        count++;
    }
    clock_gettime(CLOCK_REALTIME, &runtime2);
    time_taken = (runtime2.tv_sec - runtime1.tv_sec + (double)(runtime2.tv_nsec - runtime1.tv_nsec) / (double)BILLION);
    printf("Time take for A: %lf \n",time_taken);
}
void *countB()
{
    struct sched_param countb_param;
    countb_param.sched_priority = 1;
    pthread_setschedparam(t2, SCHED_RR, &countb_param);
    struct timespec runtime1, runtime2;
    double time_taken;
    clock_gettime(CLOCK_REALTIME, &runtime1);
    long long count = 0;
    for (long long int i = 1; i < pow(2, 32); i++)
    {
        count++;
    }
    clock_gettime(CLOCK_REALTIME, &runtime2);
    time_taken = (runtime2.tv_sec - runtime1.tv_sec + (double)(runtime2.tv_nsec - runtime1.tv_nsec) / (double)BILLION);
    printf("Time take for B: %lf \n",time_taken);
}
void *countC()
{
    struct sched_param countc_param;
    countc_param.sched_priority = 1;
    pthread_setschedparam(t3, SCHED_FIFO, &countc_param);
    struct timespec runtime1, runtime2;
    double time_taken;
    clock_gettime(CLOCK_REALTIME, &runtime1);
    long long count = 0;
    for (long long int i = 1; i < pow(2, 32); i++)
    {
        count++;
    }
    clock_gettime(CLOCK_REALTIME, &runtime2);
    time_taken = (runtime2.tv_sec - runtime1.tv_sec + (double)(runtime2.tv_nsec - runtime1.tv_nsec) / (double)BILLION);
    printf("Time take for C: %lf \n",time_taken);
}
int main()
{
    pthread_create(&t1, NULL, countA, NULL);
    pthread_create(&t2, NULL, countB, NULL);
    pthread_create(&t3, NULL, countC, NULL);
    pthread_join(t1, NULL);
    pthread_join(t3, NULL);
    pthread_join(t2, NULL);

    return 0;
}
